import React from 'react'

const ManageJobs = () => {
  return (
    <div>ManageJobs</div>
  )
}

export default ManageJobs