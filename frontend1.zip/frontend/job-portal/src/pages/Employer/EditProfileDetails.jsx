import React from 'react'

const EditProfileDetails = () => {
  return (
    <div>EditProfileDetails</div>
  )
}

export default EditProfileDetails