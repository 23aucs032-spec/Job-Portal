import React from 'react'

const EmployerProfilePage = () => {
  return (
    <div>EmployerProfilePage</div>
  )
}

export default EmployerProfilePage