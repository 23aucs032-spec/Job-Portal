import React from 'react'

const ApplicationViewer = () => {
  return (
    <div>ApplicationViewer</div>
  )
}

export default ApplicationViewer