import JobCard from "../components/JobCard";


const Jobs = () => {
return (
<div className="p-6">
<JobCard />
</div>
);
};


export default Jobs;